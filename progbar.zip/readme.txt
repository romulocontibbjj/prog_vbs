ProgBar V1.0  (C)1998 David Crowell
You may use this source code within
your own applications.  You may not
distribute it on a website without my express
permission.

ProgBar is a replacement for the MS ProgressBar
ActiveX control.  I'm releasing this as source
code for developers to include in there applications,
so they don't have to include an OCX file.  This
progress bar has some advantages over the standard
MS one.  It allow vertical bars, it repaints more
smoothly (mostly because it uses a solid bar rather
than blocks), and has better color selection support.
Not to mention smaller total package distribution
size for your software.

Be sure to visit http:/www.qtm.net/~davidc for
updates.  Email questions or comments to 
davidc@qtm.net

Enjoy :)