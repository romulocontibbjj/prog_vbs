LeeRef Deflation Algo V2.01
Coding deflate / inflate Algorithm 
Created, 2004 by Jim Reforma
Copyright(c) 2004

Special thanks to our almighty GOD and my family for being their in times of trouble and even 
in happiness.


What is LeeRef Algo?
�������������������
It is an archive manager. Archives are normal files with the difference that they can contain other files inside. Usually these files are compressed to save space.
This makes it easier to transfer files through Internet and save disk space.


New in version 2.01
�������������������
*Now you can add, extract and delete multiples files at the same time.
*Faster compression and decompression.
*Contextual menu added.
*Program stability has been improved.
*Compressed files compatible with older versions.
*IDE has only minor changes.
*Now if compressed file is corrupt, program does not crash so easily.

	This is a less-than-optimal implementation of this compression
algorithm.  It's very simple to use in your programs program.

	If the compressed version is actually larger than the original source, this
algorithm spits out a special string that contains a four- byte header and
the original source string, so the resulting string will always be at most
four bytes larger than the source string.  If you pass in True for Force, the
result will' always be LeeRef-encoded, bypassing this neat optimization.
Be aware that the output is binary data, so it might not work
nicely with some things like text boxes, certain Windows
API calls, and some SQL and database field formats.

	One cool application of this algorithm is encryption.  Because
leeref coding relies on variable-bit-length character
representations, it's next to impossible to decrypt a string
compressed with this algorithm without recognizing the
lookup tables in the header as the key to decrypting it.  You
could even strip out this lookup table and keep it as a
private key to be shared only with those you want.  Without
the lookup table, even someone equiped with this very code
would not likely be able to decrypt the string.

	One last thing.  While I've tested this algorithm with plain
text strings and even some binary files, I don't know how
much data you can cram into the compression engine before it
breaks.  With luck, it's something like 2GB.  In that case,
though, this would be pretty slow.  Also, I have not proven
beyond a doubt that this won't choke on some data, so I would
encourage you to do so to your satisfaction before putting
this into full production.  Be sure to let me know if you find
anything interesting.


Note: LeeRef - Version 2.0  Personal copyright � :) 
      You may NOT have rights to redistribute this code or program , in whole or in 
      part without my permission.  You also may not dis-assemble and debug
      as another program without my permission.  If you would like to copy this 
      program and distribute it in either as source program please contact me at 
      [virushacker23@yahoo.com] before doing so.  
       
      I would appreciate being notified of any modifications even if you do
      not intend to redistribute it.

      If you have any ideas, comments, modification, suggestions, bugs, etc. Please email me.
       
      I worked on it for a long time and I realy wanna know if you like it, 
      to see if there's any reason to keep publishing it...
  
      see you later...  and...
     
                                   
      LeeRef - Version 2.0 - Copyright � 2004
      Developed by Jim Reforma
      Copyright (c)2004
      Manila, Philippines
      e-mail: virushacker23@yahoo.com
      web: http://www.jreforma.150m.com/


All product names and trademarks are acknowledged as being the trademarks of their respective holders.

You are not allowed to distribute this program and/or the executable, unless you have written persmision from the Author / Programmer.

This program is provided "as is" without any kind of warranty.
I am not responsible for changes to the system that this program could eventually make.
Copyright � 2004 by Jim Reforma. All rights reserved.