		ReadMe for Fade.Bas
		   By: Duane Odom


Fades A Picture Box In Many Different Ways.
I wrote this using Vb4 32-bit version.  I haven't tried
it with the 16-bit version, but it should work fine
except for the call to the "Sleep" Win-API call.  That
can be fixed by simply changing the Declare for that
call.  If you find any bugs or have any improvements
in mind, or if you just have comments, E-Mail me at the 
address in the sample program.  Have Fun...


Oh Yeah...   I am not responsible for any damage this
program might, "but probably won't", do to your or any
one else's computer. 