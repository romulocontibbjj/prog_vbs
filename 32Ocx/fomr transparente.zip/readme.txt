Transparent Control v1.2 Beta 1 - Readme 10/4/96


Sidewalk Software


New for 1.2:
	1. DesignTimeAnimation Property
	2. DestHwnd Property

Fixed for 1.1a:
	1. Unloading bug where control caused a GPF when being unloaded while AutoRefresh
           was set to TRUE.

New for 1.1:
        1. AutoControlFind Property
        2. WindowRegionChanged Event
        3. Help File
        4. Property Page

This control is still freeware and my be distributed freely un an unaltered condition.
Copyright 1996

Install:

        1. Copy Transparent.OCX and Trans.Hlp to a directory.
		Example:
			MD c:\TransOCX
			CD c:\TransOCX
			copy a:\Transparent.OCX c:\TransOCX
			copy a:\Trans.Hlp c:\TransOCX
	
        2. Register the control by either using REGSVR32.EXE or browse for it from VB32.EXE or other platform.
	
        3. When using help for the first time, you will be asked to find the Trans.Hlp file..Do it.

Note: Version 2.0 is scheduled to be released by April 1997.

Web Page: www.pb.net/~pedestrian
Internet Mail: ariet@pb.net or 75317.333@compuserve.com
Compuserve: 75317,3333
AOL: ATROUW
