The VBUProgress control is Freeware.  You may 
distribute it freely with your applications.  You are free 
to distribute copies of the control by itself as long as 
you also distribute the files, unmodified, that came with
this control.  These files are listed below.

The VBUProgress control was developed with 
Visual Basic 5.0  This means that you will need the VB 5 
runtime files. I recommend using this control with VB 5
(Mainly because I haven't tested it under any other
development language.)

To register this control just run the Install.exe file.
This install will let you copy the VBUMidiPlayer to your
system directory and register it for you.

If the install does not work then try this:
Open up VB and go to the screen where you pick your 
components (In VB5 it is under the Projects|Components 
Menu). Click on the browse button. Now find the 
VBUProgress.OCX and click OK.  Thats it.  Just remember 
to check the X box next to the component name to add 
it to your project.

These are the files that you should have received with this
control.

     VBUProgress.ocx
     ReadMe.txt  (What your reading right now.)
     

VBUProgress Bar Features
---------------------------
The VBUProgressBar has the same properties as the progress bar
that ships with VB 5. The VBUProgress Bar also has these extra
properties:

CaptionStyle - 
Determines the appearance of the percentage complete caption.

FillAppearance -
Determines whether the fill indicator is 3D of flat.

FillColor - 
Used to specify the color used to fill in the percentage 
complete bar.

FillStyle - Determines how the progress bar fills. Either Segmented
or Full.

IntegralWidth - 
Forces the width of the progress bar so it displays only full
segmented boxes. This property has no effect when the FillStyle
property is set to Full.

PercentComplete - 
A read only property the returns the percentage completed in a
value between 0 and 100.

Picture -
This property will fill the percentage complete with a picture.
The Picture is best used when the FillStyle property is set
to Full.


DISCLAIMER:
-----------
THIS CONTROL IS PROVIDED AS IS AND WITHOUT ANY WARRANTIES 
WHATSOEVER.  THE USER IS ADVISED TO THOROUGHLY TEST AND DEBUG
THEIR PROGRAM.  THE USER ASSUMES THE ENTIRE RISK OF USING
THE CONTROL.  THE AUTHOR OF THIS CONTROL IS UNDER NO LEGAL
RESPONSIBILTY.

If you have any questions or comments then please send me an
EMail to larryallen@geocities.com

Also Visit my web site at
http://www.geocities.com/SiliconValley/Horizon/8806

Thank You
