Purpose of this ActiveX control:
--------------------------------

To easily compress and decompress a single file. 
Useful to backup an .mdb database.

How it works:
-------------

The control is an easy VB interface to the freeware ZLIB
compression library. You can find more info about this library using 
a search engine like Altavista and looking for "ZLIB".

The OCX is very similar to Mark Nelson's ZLibTool:
I used it and liked it, but it didn't work with VB5.
I decided to write a similar control, but using VB5 instead of C++.
In this way the conversion to future versions of VB will be simple,
since you can recompile the VB source files.

First I tried to directly use the ZLIB dll, but I did not succeed: the
data structure were impossible (at least for me) to use with VB.
So I decided to add a C function to compress or decompress a single file.

I had to rebuild the DLL and I changed its name to avoid conlicts.
Using these functions it was very easy to use the library from VB5.

How you can use it:
-------------------

You will find 3 ZIP files with this Readme.

- DLL-src.zip contains the souce code for the ZLIB library used to
  build the DLL. I don't think that you will need it to use the control.
- OCX-src.zip contains the VB source code for the ActiveX control.
  Maybe you will need it to compile the control for a newer version of VB.
- OCX.zip contains the ActiveX control. This is what you really need.
  It contains 3 files: copy them to your Windows\System directory.
  The .OCX and .DLL files are needed to compress files. The .DEP file
  is used by Setup Wizard. Before using it, you must register the OCX by
  executing the command "regsvr32 FSComprFile.ocx".

  The control looks like a standard Win95 progress bar. During operation
  the progress bar will grow.

  The control has the following properties:

    the Value property is the same of a progress bar: you can use the
    control as a standalone progress bar, if you want.

    Appearance e BorderStyle work as usual.

    InputFile is the name of the file to be compressed or decompressed.
    OutputFile is the name of the compressed of decompressed file.
    Level (default 6) is the compression level. Use higher values to
    obtain a better compression but a slower execution.

  The control has the following methods:

    Compress compresses a file.
    Decompress expands a compressed file.

    The ResultStatus property can tell you how the above methods worked 
    (0 = OK):

    ' ZLIB specific
    fsResOk = 0
    fsResErrno = -1
    fsResStreamError = -2
    fsResDataError = -3
    fsResMemError = -4
    fsResBufError = -5
    fsResVersionError = -6
    
    ' FSZlib specific
    fsResErrInputFile = -200            ' error opening input file
    fsResErrOutputFile = -201           ' error opening output file
    
    ' OCX specific
    fsResMissingInputFileName = -1500   ' missing file name
    fsResMissingOutputFileName = -1501  ' same


Code samples:
-------------

To compress a file:

'    ZlibTool1.Level = 4	' optional, default = 6
    FSComprFile1.InputFile = "Customers.mdb"
    FSComprFile1.OutputFile = "Customers.md_"
    FSComprFile1.Compress
    If FSComprFile.ResultStatus <> 0 then
      ' error checking...
    Endif

To decompress the same file:

    FSComprFile1.InputFile = "Customers.md_"
    FSComprFile1.OutputFile = "Customers.mdb"
    FSComprFile1.Decompress
    If FSComprFile.ResultStatus <> 0 then
      ' error checking...
    Endif


Acknowledgements:
-----------------

This product is based on the ZLIB library: it is a very good piece
of software and we all should be grateful to the authors.
My contribution has been only marginal, so remember to pray for those
guys when you go to sleep! :>




Please, feel free to write me if you need.

Fulvio Senore
fulsenore@tin.it

