Title: SComboBox 1.0.4 Update: 2004-09-12
Description: English: This control is a customizable ComboBox with multiple appearances. I hope you it like. Description: This usercontrol simulates a ComboBox.-------------------------------------------------------------------------------------- But adds new an great features like: - The first ComboBox On PSC that actually works in a single file control. - When the list is shown doesn't deactivate the parent form. - More than 20 Visual Styles; no images everything done by code. - Some extra cool properties----------------------------- -------------------------------------------------------- IMPORTANT NOTE -------------- So many thanks fred_cpp for his contribution for this project, some styles and Traduction to English of some comments. All rights Reserved � HACKPRO TM 2004------------------------------------------------------------------------------------------------------------------
Fixes bugs version 1.0.4-------------------------
- ItemFocus correction.
 - Clear function.
 - Border Select.
 - ScrollBar.
 - Width Text.
 - Move for the list.
 - Office 2003 Appearance.
 - Sub DrawAppearance.
 - Sub CreateText.--------------------------------------------------------------------------------
New in this version 1.0.4 (Update: 2004-09-12)---
------------------------------------------------ 
 - Now if the Font change works.
 - Now the temporary directory of Windows is used to manipulate the images.
 - Parameter ShadowText.
 - Property ListGradient.
 - Function CalcTextWidth.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56157&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
